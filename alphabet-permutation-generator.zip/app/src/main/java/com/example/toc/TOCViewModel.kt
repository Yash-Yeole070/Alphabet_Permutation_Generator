package com.example.toc

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * UI State for the Alphabet Permutation Generator application.
 */
data class TOCUiState(
    val regex: String = "(a|b)*",
    val maxLengthInput: String = "2",
    val derivedAlphabet: Set<Char> = setOf('a', 'b'),
    val regexError: String? = null,
    val maxLengthError: String? = null,

    // String Generation State
    val isGenerating: Boolean = false,
    val generatedStrings: List<String>? = null,
    val totalValidCount: Int? = null,
    val generationError: String? = null,

    // String Validation State
    val checkStringInput: String = "abba",
    val isChecking: Boolean = false,
    val validationResult: FormalRegexEngine.ValidationResult? = null,
    val checkStringError: String? = null
)

class TOCViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TOCUiState())
    val uiState: StateFlow<TOCUiState> = _uiState.asStateFlow()

    init {
        // Derive initial alphabet
        updateAlphabet("(a|b)*")
    }

    private fun updateAlphabet(regexText: String) {
        val alphabet = FormalRegexEngine.extractAlphabet(regexText)
        _uiState.update { it.copy(derivedAlphabet = alphabet) }
    }

    fun onRegexChange(newRegex: String) {
        _uiState.update {
            it.copy(
                regex = newRegex,
                regexError = null,
                generationError = null,
                validationResult = null
            )
        }
        updateAlphabet(newRegex)
    }

    fun appendToRegex(token: String) {
        val updated = _uiState.value.regex + token
        onRegexChange(updated)
    }

    fun onMaxLengthChange(newLength: String) {
        _uiState.update {
            it.copy(
                maxLengthInput = newLength,
                maxLengthError = null,
                generationError = null
            )
        }
    }

    fun onCheckStringChange(newString: String) {
        _uiState.update {
            it.copy(
                checkStringInput = newString,
                checkStringError = null,
                validationResult = null
            )
        }
    }

    fun loadExample(regex: String, defaultL: String, sampleString: String) {
        _uiState.update {
            it.copy(
                regex = regex,
                maxLengthInput = defaultL,
                checkStringInput = sampleString,
                regexError = null,
                maxLengthError = null,
                checkStringError = null,
                validationResult = null,
                generatedStrings = null,
                totalValidCount = null,
                generationError = null
            )
        }
        updateAlphabet(regex)
    }

    /**
     * Function 1: Generate all valid strings of length <= L belonging to L(Regex).
     */
    fun generateValidStrings() {
        val currentRegex = _uiState.value.regex.trim()
        val lengthStr = _uiState.value.maxLengthInput.trim()

        // 1. Validate Regular Expression
        if (currentRegex.isEmpty()) {
            _uiState.update {
                it.copy(
                    regexError = "Empty regular expression. Please enter a regular expression.",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        try {
            FormalRegexEngine.validateRegex(currentRegex)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    regexError = e.message ?: "Invalid Regular Expression syntax.",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        // 2. Validate Maximum Length L
        if (lengthStr.isEmpty()) {
            _uiState.update {
                it.copy(
                    maxLengthError = "Empty maximum length. Please enter a number between 0 and 10.",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        val maxL = lengthStr.toIntOrNull()
        if (maxL == null) {
            _uiState.update {
                it.copy(
                    maxLengthError = "Non-numeric maximum length. Please enter a valid non-negative integer.",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        if (maxL < 0) {
            _uiState.update {
                it.copy(
                    maxLengthError = "Negative maximum length is not allowed. (L ≥ 0)",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        if (maxL > 10) {
            _uiState.update {
                it.copy(
                    maxLengthError = "Maximum length cannot exceed 10.",
                    generatedStrings = null,
                    totalValidCount = null
                )
            }
            return
        }

        // 3. Clear errors and generate asynchronously
        _uiState.update {
            it.copy(
                isGenerating = true,
                regexError = null,
                maxLengthError = null,
                generationError = null
            )
        }

        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    FormalRegexEngine.generateValidStrings(currentRegex, maxL)
                }
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generatedStrings = result.validStrings,
                        totalValidCount = result.totalCount,
                        derivedAlphabet = result.alphabet,
                        generationError = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generatedStrings = null,
                        totalValidCount = null,
                        generationError = e.message ?: "Failed to generate valid strings."
                    )
                }
            }
        }
    }

    /**
     * Function 2: Validate a user-given string against the regular expression.
     */
    fun checkString() {
        val currentRegex = _uiState.value.regex.trim()
        val userStr = _uiState.value.checkStringInput.trim()

        // 1. Validate Regular Expression
        if (currentRegex.isEmpty()) {
            _uiState.update {
                it.copy(
                    regexError = "Empty regular expression. Please enter a regular expression.",
                    validationResult = null
                )
            }
            return
        }

        try {
            FormalRegexEngine.validateRegex(currentRegex)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    regexError = e.message ?: "Invalid Regular Expression syntax.",
                    validationResult = null
                )
            }
            return
        }

        _uiState.update { it.copy(isChecking = true, regexError = null, checkStringError = null) }

        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                FormalRegexEngine.validateString(currentRegex, userStr)
            }
            _uiState.update {
                it.copy(
                    isChecking = false,
                    validationResult = result
                )
            }
        }
    }
}
