package com.example.toc

/**
 * Theory of Computation (TOC) Formal Regular Expression Engine
 *
 * Implements:
 * 1. Syntax analysis and validation of Regular Expressions.
 * 2. Automatic alphabet derivation (Σ).
 * 3. Implicit concatenation insertion.
 * 4. Infix to Postfix conversion via Shunting-Yard algorithm.
 * 5. Thompson's Construction (Regex -> Non-Deterministic Finite Automaton with ε-transitions).
 * 6. ε-closure computation.
 * 7. NFA Simulation for string recognition / language membership.
 * 8. Systematic language generation up to maximum length L (0 <= |w| <= L) with cycle/explosion protection.
 *
 * Supported Operators:
 * - '|' : Union / Alternation
 * - '*' : Kleene Star (0 or more repetitions)
 * - '+' : Kleene Plus (1 or more repetitions)
 * - '()' : Grouping
 * - Implicit concatenation: e.g., 'ab', 'a(b|c)'
 */
/**
 * Represents a state in the NFA.
 */
typealias State = Int

object FormalRegexEngine {

    /**
     * Represents an NFA fragment during Thompson's construction.
     */
    data class NFAFragment(
        val start: State,
        val accept: State
    )

    /**
     * Formal NFA container holding states, transitions, alphabet, start and accept states.
     */
    data class NFA(
        val startState: State,
        val acceptState: State,
        val alphabet: Set<Char>,
        val transitions: Map<Pair<State, Char>, Set<State>>,
        val epsilonTransitions: Map<State, Set<State>>
    )

    /**
     * Result of generating valid strings.
     */
    data class GenerationResult(
        val validStrings: List<String>,
        val alphabet: Set<Char>,
        val totalCount: Int
    )

    /**
     * Result of validating a user string.
     */
    sealed class ValidationResult {
        data class Accepted(val string: String, val regex: String) : ValidationResult()
        data class Rejected(val string: String, val regex: String, val reason: String) : ValidationResult()
        data class InvalidInput(val message: String) : ValidationResult()
    }

    /**
     * Validates regular expression syntax and extracts literal alphabet.
     * Throws IllegalArgumentException with user-friendly message if syntax is invalid.
     */
    fun validateRegex(rawRegex: String): Set<Char> {
        val regex = rawRegex.trim()
        if (regex.isEmpty()) {
            throw IllegalArgumentException("Empty regular expression. Please enter a regular expression.")
        }

        // Check parentheses balance
        var balance = 0
        for (i in regex.indices) {
            val c = regex[i]
            if (c == '(') {
                balance++
                // Check for empty parentheses ()
                if (i + 1 < regex.length && regex[i + 1] == ')') {
                    throw IllegalArgumentException("Invalid Regular Expression: Empty parentheses '()' are not allowed.")
                }
            } else if (c == ')') {
                balance--
                if (balance < 0) {
                    throw IllegalArgumentException("Invalid Regular Expression: Unbalanced parentheses. Unexpected closing ')'.")
                }
            }
        }
        if (balance != 0) {
            throw IllegalArgumentException("Invalid Regular Expression: Unbalanced parentheses. Missing closing ')'.")
        }

        // Check invalid operator placements
        val firstChar = regex.first()
        if (firstChar == '*' || firstChar == '+') {
            throw IllegalArgumentException("Invalid Regular Expression: Repetition operator '$firstChar' cannot appear at the start.")
        }
        if (firstChar == '|') {
            throw IllegalArgumentException("Invalid Regular Expression: Union operator '|' cannot appear at the start.")
        }
        if (regex.last() == '|') {
            throw IllegalArgumentException("Invalid Regular Expression: Trailing '|' operator without right operand.")
        }

        for (i in 0 until regex.length - 1) {
            val curr = regex[i]
            val next = regex[i + 1]

            // Consecutive binary operators
            if (curr == '|' && (next == '|' || next == '*' || next == '+' || next == ')')) {
                throw IllegalArgumentException("Invalid Regular Expression: Invalid operator placement after '|'.")
            }
            if (curr == '(' && (next == '|' || next == '*' || next == '+')) {
                throw IllegalArgumentException("Invalid Regular Expression: Operator '$next' cannot directly follow '('.")
            }
        }

        val alphabet = extractAlphabet(regex)
        if (alphabet.isEmpty()) {
            throw IllegalArgumentException("Invalid Regular Expression: No literal symbols found in the regular expression.")
        }

        return alphabet
    }

    /**
     * Extracts all unique literal symbols from the regular expression.
     */
    fun extractAlphabet(regex: String): Set<Char> {
        val reserved = setOf('|', '*', '+', '(', ')')
        return regex.filter { !it.isWhitespace() && it !in reserved }.toSortedSet()
    }

    /**
     * Step 1: Preprocess regular expression to insert explicit concatenation operators ('.').
     * For example:
     * - "ab" -> "a.b"
     * - "a(b|c)" -> "a.(b|c)"
     * - "(a|b)*a" -> "(a|b)*.a"
     */
    fun insertConcatenation(rawRegex: String): String {
        val s = rawRegex.filter { !it.isWhitespace() }
        if (s.isEmpty()) return ""

        val result = StringBuilder()
        for (i in s.indices) {
            val c1 = s[i]
            result.append(c1)

            if (i + 1 < s.length) {
                val c2 = s[i + 1]

                val c1CanBeFollowedByConcat = isLiteral(c1) || c1 == '*' || c1 == '+' || c1 == ')'
                val c2CanBePrecededByConcat = isLiteral(c2) || c2 == '('

                if (c1CanBeFollowedByConcat && c2CanBePrecededByConcat) {
                    result.append('.')
                }
            }
        }
        return result.toString()
    }

    private fun isLiteral(c: Char): Boolean {
        return c != '|' && c != '*' && c != '+' && c != '(' && c != ')' && c != '.'
    }

    /**
     * Step 2: Convert Infix regular expression with explicit concatenation to Postfix (Reverse Polish Notation)
     * using the Shunting-Yard algorithm.
     *
     * Operator precedence:
     * - '*' and '+' : 3 (highest, unary postfix)
     * - '.' (concat) : 2 (left-associative)
     * - '|' (union)  : 1 (left-associative)
     */
    fun infixToPostfix(infixWithConcat: String): String {
        val output = StringBuilder()
        val stack = ArrayDeque<Char>()

        fun precedence(op: Char): Int = when (op) {
            '*', '+' -> 3
            '.' -> 2
            '|' -> 1
            else -> 0
        }

        for (c in infixWithConcat) {
            when {
                isLiteral(c) -> {
                    output.append(c)
                }
                c == '(' -> {
                    stack.addLast(c)
                }
                c == ')' -> {
                    while (stack.isNotEmpty() && stack.last() != '(') {
                        output.append(stack.removeLast())
                    }
                    if (stack.isNotEmpty() && stack.last() == '(') {
                        stack.removeLast()
                    }
                }
                c == '*' || c == '+' -> {
                    // Unary postfix operators can be placed immediately or resolved by precedence
                    while (stack.isNotEmpty() && stack.last() != '(' && precedence(stack.last()) >= precedence(c)) {
                        output.append(stack.removeLast())
                    }
                    stack.addLast(c)
                }
                c == '.' || c == '|' -> {
                    while (stack.isNotEmpty() && stack.last() != '(' && precedence(stack.last()) >= precedence(c)) {
                        output.append(stack.removeLast())
                    }
                    stack.addLast(c)
                }
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.removeLast()
            if (top != '(' && top != ')') {
                output.append(top)
            }
        }

        return output.toString()
    }

    /**
     * Step 3: Thompson's Construction
     * Constructs a Non-Deterministic Finite Automaton with ε-transitions from the postfix regular expression.
     */
    fun buildNFA(rawRegex: String): NFA {
        val alphabet = validateRegex(rawRegex)
        val formatted = insertConcatenation(rawRegex)
        val postfix = infixToPostfix(formatted)

        var stateCounter = 0
        fun newState(): State = stateCounter++

        val transitions = mutableMapOf<Pair<State, Char>, MutableSet<State>>()
        val epsilonTransitions = mutableMapOf<State, MutableSet<State>>()

        fun addTransition(from: State, symbol: Char, to: State) {
            transitions.getOrPut(Pair(from, symbol)) { mutableSetOf() }.add(to)
        }

        fun addEpsilonTransition(from: State, to: State) {
            epsilonTransitions.getOrPut(from) { mutableSetOf() }.add(to)
        }

        val stack = ArrayDeque<NFAFragment>()

        for (token in postfix) {
            when {
                isLiteral(token) -> {
                    // Thompson rule for literal symbol:
                    // s0 -- token --> s1
                    val s0 = newState()
                    val s1 = newState()
                    addTransition(s0, token, s1)
                    stack.addLast(NFAFragment(s0, s1))
                }
                token == '.' -> {
                    // Thompson rule for concatenation:
                    // frag1.accept -- ε --> frag2.start
                    if (stack.size < 2) throw IllegalStateException("Malformed regex for concatenation")
                    val frag2 = stack.removeLast()
                    val frag1 = stack.removeLast()
                    addEpsilonTransition(frag1.accept, frag2.start)
                    stack.addLast(NFAFragment(frag1.start, frag2.accept))
                }
                token == '|' -> {
                    // Thompson rule for union:
                    // newStart -- ε --> frag1.start & frag2.start
                    // frag1.accept & frag2.accept -- ε --> newAccept
                    if (stack.size < 2) throw IllegalStateException("Malformed regex for union")
                    val frag2 = stack.removeLast()
                    val frag1 = stack.removeLast()
                    val newStart = newState()
                    val newAccept = newState()

                    addEpsilonTransition(newStart, frag1.start)
                    addEpsilonTransition(newStart, frag2.start)
                    addEpsilonTransition(frag1.accept, newAccept)
                    addEpsilonTransition(frag2.accept, newAccept)

                    stack.addLast(NFAFragment(newStart, newAccept))
                }
                token == '*' -> {
                    // Thompson rule for Kleene star:
                    // newStart -- ε --> frag.start & newAccept
                    // frag.accept -- ε --> frag.start & newAccept
                    if (stack.isEmpty()) throw IllegalStateException("Malformed regex for Kleene star")
                    val frag = stack.removeLast()
                    val newStart = newState()
                    val newAccept = newState()

                    addEpsilonTransition(newStart, frag.start)
                    addEpsilonTransition(newStart, newAccept)
                    addEpsilonTransition(frag.accept, frag.start)
                    addEpsilonTransition(frag.accept, newAccept)

                    stack.addLast(NFAFragment(newStart, newAccept))
                }
                token == '+' -> {
                    // Thompson rule for Kleene plus:
                    // newStart -- ε --> frag.start
                    // frag.accept -- ε --> frag.start & newAccept
                    if (stack.isEmpty()) throw IllegalStateException("Malformed regex for Kleene plus")
                    val frag = stack.removeLast()
                    val newStart = newState()
                    val newAccept = newState()

                    addEpsilonTransition(newStart, frag.start)
                    addEpsilonTransition(frag.accept, frag.start)
                    addEpsilonTransition(frag.accept, newAccept)

                    stack.addLast(NFAFragment(newStart, newAccept))
                }
            }
        }

        if (stack.size != 1) {
            throw IllegalArgumentException("Invalid Regular Expression: Failed to construct finite automaton.")
        }

        val finalFragment = stack.removeLast()
        return NFA(
            startState = finalFragment.start,
            acceptState = finalFragment.accept,
            alphabet = alphabet,
            transitions = transitions,
            epsilonTransitions = epsilonTransitions
        )
    }

    /**
     * Step 4: Computes the ε-closure for a set of states.
     * Finds all states reachable from the initial set via zero or more ε-transitions.
     */
    fun epsilonClosure(nfa: NFA, states: Set<State>): Set<State> {
        val closure = states.toMutableSet()
        val queue = ArrayDeque(states)

        while (queue.isNotEmpty()) {
            val state = queue.removeFirst()
            val epsTargets = nfa.epsilonTransitions[state] ?: emptySet()
            for (target in epsTargets) {
                if (closure.add(target)) {
                    queue.addLast(target)
                }
            }
        }
        return closure
    }

    /**
     * Step 5: Computes the transition from a state set on a given alphabet symbol:
     * move(S, symbol) = ε-closure( ∪ { transitions(s, symbol) | s ∈ S } )
     */
    fun move(nfa: NFA, states: Set<State>, symbol: Char): Set<State> {
        val nextStates = mutableSetOf<State>()
        for (s in states) {
            val targets = nfa.transitions[Pair(s, symbol)]
            if (targets != null) {
                nextStates.addAll(targets)
            }
        }
        return epsilonClosure(nfa, nextStates)
    }

    /**
     * Step 6: Validates a user-given string against the regular expression using NFA simulation.
     */
    fun validateString(rawRegex: String, userString: String): ValidationResult {
        val cleanRegex = rawRegex.trim()
        val nfa = try {
            buildNFA(cleanRegex)
        } catch (e: Exception) {
            return ValidationResult.InvalidInput(e.message ?: "Invalid Regular Expression syntax.")
        }

        val alphabet = nfa.alphabet
        // If string is "ε", treat as empty string
        val effectiveString = if (userString == "ε") "" else userString

        // Validate that all symbols in userString belong to alphabet Σ
        for (ch in effectiveString) {
            if (ch !in alphabet) {
                return ValidationResult.Rejected(
                    string = effectiveString,
                    regex = cleanRegex,
                    reason = "The entered string contains symbols that are not part of the regular expression's alphabet."
                )
            }
        }

        // Simulate NFA
        var currentStates = epsilonClosure(nfa, setOf(nfa.startState))
        for (ch in effectiveString) {
            currentStates = move(nfa, currentStates, ch)
            if (currentStates.isEmpty()) {
                // Dead state reached early, cannot accept
                break
            }
        }

        val isAccepted = nfa.acceptState in currentStates

        return if (isAccepted) {
            ValidationResult.Accepted(string = effectiveString, regex = cleanRegex)
        } else {
            ValidationResult.Rejected(
                string = effectiveString,
                regex = cleanRegex,
                reason = "'$effectiveString' does not belong to the language represented by '$cleanRegex'."
            )
        }
    }

    /**
     * Step 7: Generates all valid strings of length <= L (0 <= |w| <= L) belonging to the language.
     * Performs a breadth-first search over NFA state subsets, pruning branches that hit empty state sets.
     */
    fun generateValidStrings(rawRegex: String, maxL: Int): GenerationResult {
        if (maxL < 0) {
            throw IllegalArgumentException("Negative maximum length is not allowed.")
        }
        if (maxL > 10) {
            throw IllegalArgumentException("Maximum length cannot exceed 10.")
        }

        val nfa = buildNFA(rawRegex)
        val alphabet = nfa.alphabet
        val validStrings = mutableSetOf<String>()

        val initialStates = epsilonClosure(nfa, setOf(nfa.startState))
        if (nfa.acceptState in initialStates) {
            validStrings.add("") // ε (empty string)
        }

        if (maxL > 0 && alphabet.isNotEmpty()) {
            // BFS Queue holds pairs: (current string, reachable NFA state set)
            val queue = ArrayDeque<Pair<String, Set<State>>>()
            queue.addLast(Pair("", initialStates))

            var totalGeneratedStrings = 0
            val maxAllowedExploration = 60_000

            while (queue.isNotEmpty()) {
                val (currStr, currStates) = queue.removeFirst()

                if (currStr.length < maxL) {
                    for (symbol in alphabet) {
                        totalGeneratedStrings++
                        if (totalGeneratedStrings > maxAllowedExploration) {
                            throw IllegalStateException("Too many possible strings. Please use a smaller value of L.")
                        }

                        val nextStates = move(nfa, currStates, symbol)
                        if (nextStates.isNotEmpty()) {
                            val nextStr = currStr + symbol
                            if (nfa.acceptState in nextStates) {
                                validStrings.add(nextStr)
                                if (validStrings.size > 15_000) {
                                    throw IllegalStateException("Too many possible strings. Please use a smaller value of L.")
                                }
                            }
                            if (nextStr.length < maxL) {
                                queue.addLast(Pair(nextStr, nextStates))
                            }
                        }
                    }
                }
            }
        }

        // Sort results:
        // 1. Increasing string length
        // 2. Lexicographical order for strings of same length
        val sortedList = validStrings.sortedWith(
            compareBy<String> { it.length }.thenBy { it }
        )

        return GenerationResult(
            validStrings = sortedList,
            alphabet = alphabet,
            totalCount = sortedList.size
        )
    }
}
