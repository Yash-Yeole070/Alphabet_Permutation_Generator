package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryLight = Color(0xFF3B82F6)
val PrimaryDark = Color(0xFF1D4ED8)

val AccentCyan = Color(0xFF0284C7)
val AccentPurple = Color(0xFF7C3AED)

val AcceptGreen = Color(0xFF059669)
val AcceptGreenLight = Color(0xFFD1FAE5)
val AcceptGreenText = Color(0xFF065F46)

val RejectRed = Color(0xFFDC2626)
val RejectRedLight = Color(0xFFFEE2E2)
val RejectRedText = Color(0xFF991B1B)

val Amber600 = Color(0xFFD97706)
val Amber100 = Color(0xFFFEF3C7)
