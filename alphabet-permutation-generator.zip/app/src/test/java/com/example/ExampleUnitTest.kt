package com.example

import com.example.toc.FormalRegexEngine
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests covering all 12 required test cases from Section 11 of the specification,
 * plus string generation and edge cases.
 */
class ExampleUnitTest {

    @Test
    fun test1_a_star_aaa_accepted() {
        val result = FormalRegexEngine.validateString("a*", "aaa")
        assertTrue("Test 1: a* with aaa must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test2_a_star_aab_rejected() {
        val result = FormalRegexEngine.validateString("a*", "aab")
        assertTrue("Test 2: a* with aab must be REJECTED", result is FormalRegexEngine.ValidationResult.Rejected)
    }

    @Test
    fun test3_a_or_b_a_accepted() {
        val result = FormalRegexEngine.validateString("a|b", "a")
        assertTrue("Test 3: a|b with a must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test4_a_or_b_ab_rejected() {
        val result = FormalRegexEngine.validateString("a|b", "ab")
        assertTrue("Test 4: a|b with ab must be REJECTED", result is FormalRegexEngine.ValidationResult.Rejected)
    }

    @Test
    fun test5_ab_ab_accepted() {
        val result = FormalRegexEngine.validateString("ab", "ab")
        assertTrue("Test 5: ab with ab must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test6_ab_abc_rejected() {
        val result = FormalRegexEngine.validateString("ab", "abc")
        assertTrue("Test 6: ab with abc must be REJECTED", result is FormalRegexEngine.ValidationResult.Rejected)
    }

    @Test
    fun test7_a_or_b_star_abba_accepted() {
        val result = FormalRegexEngine.validateString("(a|b)*", "abba")
        assertTrue("Test 7: (a|b)* with abba must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test8_a_or_b_star_abc_rejected() {
        val result = FormalRegexEngine.validateString("(a|b)*", "abc")
        assertTrue("Test 8: (a|b)* with abc must be REJECTED", result is FormalRegexEngine.ValidationResult.Rejected)
    }

    @Test
    fun test9_a_star_empty_accepted() {
        val result1 = FormalRegexEngine.validateString("a*", "")
        assertTrue("Test 9: a* with empty string must be ACCEPTED", result1 is FormalRegexEngine.ValidationResult.Accepted)

        val result2 = FormalRegexEngine.validateString("a*", "ε")
        assertTrue("Test 9: a* with ε must be ACCEPTED", result2 is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test10_a_bc_ab_accepted() {
        val result = FormalRegexEngine.validateString("a(b|c)", "ab")
        assertTrue("Test 10: a(b|c) with ab must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test11_a_bc_ac_accepted() {
        val result = FormalRegexEngine.validateString("a(b|c)", "ac")
        assertTrue("Test 11: a(b|c) with ac must be ACCEPTED", result is FormalRegexEngine.ValidationResult.Accepted)
    }

    @Test
    fun test12_a_bc_aa_rejected() {
        val result = FormalRegexEngine.validateString("a(b|c)", "aa")
        assertTrue("Test 12: a(b|c) with aa must be REJECTED", result is FormalRegexEngine.ValidationResult.Rejected)
    }

    @Test
    fun testGeneration_a_or_b_star_length_2() {
        val genResult = FormalRegexEngine.generateValidStrings("(a|b)*", 2)
        assertEquals(7, genResult.totalCount)
        val expected = listOf("", "a", "b", "aa", "ab", "ba", "bb")
        assertEquals(expected, genResult.validStrings)
    }

    @Test
    fun testGeneration_plus_operator() {
        val genResult = FormalRegexEngine.generateValidStrings("a+", 3)
        // a, aa, aaa (no empty string because + requires at least 1)
        val expected = listOf("a", "aa", "aaa")
        assertEquals(expected, genResult.validStrings)
    }
}

